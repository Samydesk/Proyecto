/*Modal1*/ 
const modalSolicitado = document.querySelector('.modalSolicitado');
const modal1 = new bootstrap.Modal(document.getElementById('modal1'));

modalSolicitado.addEventListener('click', () => {
  modal1.show();
});

/*Modal2 */
const modalHomicidio = document.querySelector('.modalHomicidio');
const modal2 = new bootstrap.Modal(document.getElementById('modal2'));

modalHomicidio.addEventListener('click', () => {
  modal2.show();
});

/*Modal3 */
const modalDroga = document.querySelector('.modalDroga');
const modal3 = new bootstrap.Modal(document.getElementById('modal3'));

modalDroga.addEventListener('click', () => {
  modal3.show();
});

/*Modal4 */
const modalSecuestro = document.querySelector('.modalSecuestro');
const modal4 = new bootstrap.Modal(document.getElementById('modal4'));

modalSecuestro.addEventListener('click', () => {
  modal4.show();
});

/*Modal5 */
const modalViolacion = document.querySelector('.modalViolacion');
const modal5 = new bootstrap.Modal(document.getElementById('modal5'));

modalViolacion.addEventListener('click', () => {
  modal5.show();
});


/*Modal6 */
const modalPorteIlicito = document.querySelector('.modalPorteIlicito');
const modal6 = new bootstrap.Modal(document.getElementById('modal6'));

modalPorteIlicito.addEventListener('click', () => {
  modal6.show();
});

/*Modal7*/
const modalRoboGenerico = document.querySelector('.modalRoboGenerico');
const modal7 = new bootstrap.Modal(document.getElementById('modal7'));

modalRoboGenerico.addEventListener('click', () => {
  modal7.show();
});

/*Modal8*/
const modalHurtoGenerico = document.querySelector('.modalHurtoGenerico');
const modal8 = new bootstrap.Modal(document.getElementById('modal8'));

modalHurtoGenerico.addEventListener('click', () => {
  modal8.show();
});

/*Modal9*/
const modalViolenciaGenero = document.querySelector('.modalViolenciaGenero');
const modal9 = new bootstrap.Modal(document.getElementById('modal9'));

modalViolenciaGenero.addEventListener('click', () => {
  modal9.show();
});

/*Modal10*/
const modalLesiones = document.querySelector('.modalLesiones');
const modal10 = new bootstrap.Modal(document.getElementById('modal10'));

modalLesiones.addEventListener('click', () => {
  modal10.show();
});

/*Modal11*/
const modalResistencia = document.querySelector('.modalResistencia');
const modal11 = new bootstrap.Modal(document.getElementById('modal11'));

modalResistencia.addEventListener('click', () => {
  modal11.show();
});

/*Modal12*/
const modalOtros = document.querySelector('.modalOtros');
const modal12 = new bootstrap.Modal(document.getElementById('modal12'));

modalOtros.addEventListener('click', () => {
  modal12.show();
});
